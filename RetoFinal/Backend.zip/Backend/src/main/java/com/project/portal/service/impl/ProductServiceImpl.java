package com.project.portal.service.impl;

import com.project.portal.entity.CustomerEntity;
import com.project.portal.entity.ProductEntity;
import com.project.portal.model.Customer;
import com.project.portal.model.Product;
import com.project.portal.service.ProductServiceInterface;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductServiceInterface {


    @Override
    public List<ProductEntity> findByClient() {
        return null;
    }

    @Override
    public ProductEntity update(Product dto) {
        return null;
    }

    @Override
    public ProductEntity create(Product dto) {
        return null;
    }

    @Override
    public void delete(String id) {

    }
}
