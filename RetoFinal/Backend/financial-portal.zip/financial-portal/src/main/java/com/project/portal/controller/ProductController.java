package com.project.portal.controller;

import org.springframework.stereotype.Component;

@Component
public class ProductController {


}
