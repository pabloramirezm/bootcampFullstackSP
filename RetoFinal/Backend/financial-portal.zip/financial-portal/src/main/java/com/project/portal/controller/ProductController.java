package com.project.portal.controller;

import com.project.portal.entity.ProductEntity;
import com.project.portal.model.Product;
import com.project.portal.service.ProductServiceInterface;
import com.project.portal.util.DataConversionUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping(path = "product", produces = MediaType.APPLICATION_JSON_VALUE)
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.DELETE, RequestMethod.PUT})
public class ProductController {


    private final ProductServiceInterface queryService;
    private final ModelMapper modelMapper;
    private final DataConversionUtil dataConversion;

    @Autowired
    public ProductController(final ProductServiceInterface queryService, final ModelMapper modelMapper, DataConversionUtil dataConversion) {
        this.queryService = queryService;
        this.modelMapper = modelMapper;
        this.dataConversion = dataConversion;
    }


    @GetMapping(params = {"id"})
    public List<Product> findById(@RequestParam("id") final String id) {
        try {
            return queryService.findByCustomer(id)
                    .parallelStream()
                    .map(entity -> modelMapper.map(entity, Product.class))
                    .collect(Collectors.toList());

        } catch (final Exception ex) {
            System.out.println("Error");
            return new ArrayList<>();
        }


    }


    @PostMapping(params = {"id"})
    public ResponseEntity<String> create(@RequestParam("id") final String idClient, @RequestBody final Product product) {
        try {
            if(product.getBalance() < 0.0){
                return ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body("La cuenta no puede crearse con un saldo menor a 0");
            }
            final ProductEntity created = queryService.create(product,idClient);
            return buildResponse(created);
        } catch (final Exception ex) {
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
                    .body(ex.getMessage());
        }
    }




    @PutMapping
    public ResponseEntity<String> update(@RequestBody final Product product) {
        try {
            final ProductEntity updated = queryService.update(product);
            if(Objects.isNull(updated)){
                return ResponseEntity.status(HttpStatus.ACCEPTED)
                        .body("El producto que trata de modificar no existe");
            }
            return buildResponse(updated);
        } catch (final Exception ex) {
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
                    .body(ex.getMessage());
        }
    }

    @DeleteMapping(params = {"id"})
    public ResponseEntity delete(@RequestParam("id") final String id) {

        try {
            queryService.delete(id);
            return ResponseEntity.status(HttpStatus.ACCEPTED)
                    .body("Producto eliminado con exito");
        } catch (final Exception ex) {
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
                    .body(ex.getMessage());
        }

    }

    private ResponseEntity<String> buildResponse(final ProductEntity entity) {
        final String jsonResponse = dataConversion.dtoToJson(modelMapper.map(entity, Product.class));
        return ResponseEntity.ok(jsonResponse);
    }
    

}
