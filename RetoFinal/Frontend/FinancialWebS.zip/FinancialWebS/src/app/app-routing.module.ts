import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountsComponent } from './screens/accounts/accounts.component';
import { AddaccountComponent } from './screens/addaccount/addaccount.component';
import { AddcustomerComponent } from './screens/addcustomer/addcustomer.component';
import { CustomersComponent } from './screens/customers/customers.component';
import { DashboardComponent } from './screens/dashboard/dashboard.component';
import { LoginComponent } from './screens/login/login.component';
import { TransactionComponent } from './screens/transaction/transaction.component';
import { EditcustomerComponent } from './screens/editcustomer/editcustomer.component';

const routes: Routes = [
  {path:'' , redirectTo:'login' , pathMatch:'full'},
  // {path:'' , redirectTo:'dashboard' , pathMatch:'full'},
  {path:'login' , component:LoginComponent},
  {path:'dashboard' , component:DashboardComponent},
  {path:'accounts' , component:AccountsComponent},
  {path:'addaccount' , component:AddaccountComponent},
  {path:'editcustomer/:idNumber' , component:EditcustomerComponent},
  {path:'customers' , component:CustomersComponent},
  {path:'addcustomer' , component:AddcustomerComponent},
  {path:'transaction' , component:TransactionComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [LoginComponent,DashboardComponent,AccountsComponent,AddaccountComponent,
 CustomersComponent,AddcustomerComponent,TransactionComponent]
//  