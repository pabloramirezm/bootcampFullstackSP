import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { customerEditI } from '../../models/customeredit.interface';
import { ResponseI } from '../../models/response.interface';
import { ApiService } from '../../services/api/api.service';
import { AlertsService } from '../../services/alertas/alerts.service';
import { Router, ActivatedRoute } from '@angular/router';
import { from } from 'rxjs';
import { EditcustomerComponent } from '../editcustomer/editcustomer.component';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.css']
})
export class AddcustomerComponent implements OnInit {
 
  newCustomer! : customerEditI;
  newForm = new FormGroup({
    name :  new FormControl ('')  ,
    lastName : new FormControl(''),
    idNumber:  new FormControl(''),
    email :   new FormControl(''),
    dateOfBirth : new FormControl(''),
    typeId:   new FormControl(''),
    token: new FormControl('')

});


  constructor(private api:ApiService, private router:Router, private alert:AlertsService) { }

  ngOnInit(): void {
    let token = localStorage.getItem('token');
    this.newForm.patchValue({
      'token' : token
    });
  }

  postForm(){
    Object.assign(this.newForm.value, this.newCustomer);
      this.api.postCustomer(this.newForm.value).subscribe( data =>{
          console.log(data);
      })
  }

  exit(){
    this.router.navigate(['dashboard']);
  }

}