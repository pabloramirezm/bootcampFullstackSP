import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { customerEditI } from '../../models/customeredit.interface';
import { ResponseI } from '../../models/response.interface';
import { ApiService } from '../../services/api/api.service';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { AlertsService } from '../../services/alertas/alerts.service';
import { HttpBackend, HttpClient, HttpClientJsonpModule, HttpErrorResponse, HttpHeaderResponse } from '@angular/common/http';

 
@Component({
  selector: 'app-editcustomer',
  templateUrl: './editcustomer.component.html',
  styleUrls: ['./editcustomer.component.css']
})
export class EditcustomerComponent implements OnInit {
 
  constructor(private activerouter:ActivatedRoute , private router:Router , 
    private api:ApiService, private alerts:AlertsService){
         }
        //  
   dateCustomer !: customerEditI;

    // editForm = new FormGroup({
    // name :  new FormControl ('')  ,
    // lastName : new FormControl(''),
    // idNumber:  new FormControl(''),
    // email :   new FormControl(''),
    // dateOfBirth : new FormControl(''),
    // typeId:   new FormControl(''),
    // token: new FormControl('')

    editForm = new FormGroup({
      name :  new FormControl ('',[Validators.required])  ,
      lastName : new FormControl('',[Validators.required]),
      idNumber:  new FormControl('',[Validators.required]),
      email :   new FormControl('', [Validators.email]),
      dateOfBirth : new FormControl('',[Validators.required]),
      typeId:   new FormControl('',[Validators.required]),
      token: new FormControl('',[Validators.required])

  });

 ngOnInit(): void{
  let customerid = this.activerouter.snapshot.paramMap.get('idNumber');
  let token = this.getToken();
  this.api.getOneCustomer(customerid).subscribe(data=>{

    this.dateCustomer = data;
    console.log(data);
      this.editForm.setValue({
      'name': this.dateCustomer.name,
      'lastName': this.dateCustomer.lastName,
      'idNumber': this.dateCustomer.idNumber,
      'email': this.dateCustomer.email,
      'dateOfBirth': this.dateCustomer.dateOfBirth,
      'typeId': this.dateCustomer.typeId,
      'token' : token
    });
    // console.log(this.editForm.value);
  })
   }  

  getToken(){
    return localStorage.getItem('token');
  }

  postForm(){

    //this.dateCustomer.name = String(this.editForm.value.name);
    Object.assign(this.dateCustomer, this.editForm.value);
    // console.log(this.dateCustomer);
    
    this.api.putCustomer(this.dateCustomer).subscribe(data =>{
      let response:ResponseI = data;
      console.log(response.status);
      console.log(response.result);
      if(response.result == '200 OK' ){ 
        this.alerts.showSuccess('Dates modificaded','Done');
        this.router.navigate(['dashboard']);
      }else{
        this.alerts.showError('Customer Not Modificated','Error');
      }
  })
}
delete(){
  
  // let datos:customerEditI = this.editForm.value;
  Object.assign(this.dateCustomer, this.dateCustomer);
  this.api.deleteCustomer(this.dateCustomer.idNumber).subscribe(data =>{
        let respuesta: ResponseI |any= data;
      if(respuesta.status == "200"){
          this.alerts.showSuccess('Customer deleted','Done');
          this.router.navigate(['dashboard']);
      }else{
          this.alerts.showError(respuesta.result.error_msg,'Error');
      }
  })
}


exit(){
  this.router.navigate(['dashboard']);
}




}
