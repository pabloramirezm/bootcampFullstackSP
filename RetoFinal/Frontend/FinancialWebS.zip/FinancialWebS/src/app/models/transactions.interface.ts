export interface TransactionI{
    id : string;
    transactionType : string;
    description : string;
    valueTransaction : number;
    movementType : string;
    transactionDate : string;
    accountNumber1: string;
    accountNumber2: string;

}