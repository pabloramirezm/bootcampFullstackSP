export interface TransactionI{
    id : string;
    transactionType : string;
    description : string;
    valueTransaction : number;
    movementType : string;
    transactionDate : string;
    accountNumber: string;
    

}