
export interface ResponseI{
    status_code: string | any ; 
    result : any  ;
}