
export interface ResponseI{
    status: string | {responseType:'json'} ; 
    result : any  | {responseType:'json'};
}