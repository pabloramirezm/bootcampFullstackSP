
export interface customersListI{
    id : string ;
    name : string ; 
    lastName : string ;
    idNumber: string ;
    email : string ;
    rol : string ;
    dateOfBirth : string ;
    creationDate : string;
    typeId: string ;
    modificationDate: string;
    
}