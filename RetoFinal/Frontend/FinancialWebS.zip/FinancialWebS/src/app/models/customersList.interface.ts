
export interface customersListI{
    id : number;
    name : string ; 
    lastName : string ;
    idNumber: string ;
    email : string ;
    rol : string ;
    dateOfBirth : string ;
    creationDate : string;
    typeId: string ;
    modificationDate: string;
    
}