export interface customerEditI{
    
   
    name : string ;
    lastName : string ;
    idNumber: string ;
    email: string ;
    dateOfBirth: string  ;
    typeId: string ;
   
}