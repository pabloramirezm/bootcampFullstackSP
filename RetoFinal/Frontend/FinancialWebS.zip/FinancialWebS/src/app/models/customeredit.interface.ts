export interface customerEditI{
    
    id: number;
    name : string ;
    lastName : string ;
    idNumber: string ;
    email: string ;
    dateOfBirth: string  ;
    typeId: string ;
   
}