import { Injectable } from '@angular/core';
import { LoginI } from '../../models/login.interface';
import { ResponseI } from '../../models/response.interface';
import { customersListI } from '../../models/customersList.interface';
import { HttpClient, HttpHeaders, HttpStatusCode } from '@angular/common/http';
import { Observable } from 'rxjs';
import { customerEditI } from '../../models/customeredit.interface';



@Injectable({
  providedIn: 'root'
})
export class ApiService {
  

  url: string = "http://api.solodata.es/";
  url1: string = "http://localhost:8082/";
  idNumber:string |any;
  constructor(private http:HttpClient ) { }

  LoginBy(form: LoginI) {
    let direccion = this.url + "auth";
    return this.http.post<ResponseI>(direccion,form);
  }

  getAllCustomers():Observable<customersListI[]>{
    let direccion = this.url1 + "customer" ;
    return this.http.get<customersListI[]>(direccion,{responseType:'json'});
  }
 
  getOneCustomer(idNumber:any):Observable<customerEditI>{
    let direccion = this.url1 + "customer?id=" + idNumber;
    return this.http.get<customerEditI>(direccion);
      
  }  
  putCustomer(form:customerEditI):Observable<ResponseI>{
    let direccion = this.url1 + "customer";
    return this.http.put<ResponseI>(direccion, form,{responseType:'json'});
   
  }
  
  deleteCustomer(idNumber:any):Observable<{}>{
    
    let direccion = this.url1 + "customer?id=" + idNumber;
    return this.http.delete(direccion,{responseType:'json'});
    }
  postCustomer(idNumber:any):Observable<customerEditI>{
    let direccion = this.url1 + "customer?id=" ;
    return this.http.post<customerEditI>(direccion,idNumber,{responseType:'json'});
    } 
  
}

